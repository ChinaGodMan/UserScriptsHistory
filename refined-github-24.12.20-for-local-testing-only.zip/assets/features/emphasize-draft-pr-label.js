import features from '../feature-manager.js';

void features.addCssFeature(import.meta.url);

/*

Test URLs:

- https://github.com/refined-github/refined-github/pulls
- https://github.com/pulls

*/
