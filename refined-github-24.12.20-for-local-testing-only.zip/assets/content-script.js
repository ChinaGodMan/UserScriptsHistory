// Workaround to add ESM support to content scripts
void import(chrome.runtime.getURL('assets/refined-github.js'));
