import { init } from './webext-dynamic-content-scripts-lib.js';

init();
