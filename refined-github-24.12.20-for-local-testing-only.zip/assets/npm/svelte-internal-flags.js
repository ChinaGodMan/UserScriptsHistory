let legacy_mode_flag = false;

export { legacy_mode_flag };
