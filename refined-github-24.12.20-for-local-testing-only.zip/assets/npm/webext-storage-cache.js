import cache from './webext-storage-cache-legacy.js';

const globalCache = {
    clear: cache.clear,
};

export { globalCache };
