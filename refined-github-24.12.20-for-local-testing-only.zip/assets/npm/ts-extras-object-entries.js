const objectEntries = Object.entries;

export { objectEntries };
