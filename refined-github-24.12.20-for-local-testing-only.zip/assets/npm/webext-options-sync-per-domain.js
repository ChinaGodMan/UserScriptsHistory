import memoize, { memoizeDecorator } from './memoize.js';
import { patternToRegex } from './webext-patterns.js';
import OptionsSync from './webext-options-sync.js';
import { isBackgroundPage, isContentScript } from './webext-detect.js';
import { normalizeManifestPermissions, queryAdditionalPermissions } from './webext-permissions.js';

var __decorate = (globalThis && globalThis.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
const defaultOrigins = memoize(() => patternToRegex(...normalizeManifestPermissions().origins));
function parseHost(origin) {
    return origin.includes('//')
        ? origin.split('/')[2].replace('*.', '')
        : origin;
}
class OptionsSyncPerDomain {
    static migrations = OptionsSync.migrations;
    #defaultOptions;
    constructor(options) {
        this.#defaultOptions = {
            ...options,
            storageName: options.storageName ?? 'options',
        };
        if (!isBackgroundPage()) {
            return;
        }
        if (options.migrations?.length > 0) {
            this.getAllOrigins();
        }
        chrome.permissions.onRemoved.addListener(({ origins }) => {
            const storageKeysToRemove = (origins ?? [])
                .filter(key => !defaultOrigins().test(key))
                .map(key => this.getStorageNameForOrigin(key));
            chrome.storage.sync.remove(storageKeysToRemove);
        });
    }
    getOptionsForOrigin(origin = location.origin) {
        if (!origin.startsWith('http') || defaultOrigins().test(origin)) {
            return new OptionsSync(this.#defaultOptions);
        }
        return new OptionsSync({
            ...this.#defaultOptions,
            storageName: this.getStorageNameForOrigin(origin),
        });
    }
    async getAllOrigins() {
        if (isContentScript()) {
            throw new Error('This function only works on extension pages');
        }
        const instances = new Map();
        instances.set('default', this.getOptionsForOrigin());
        const { origins } = await queryAdditionalPermissions({ strictOrigins: false });
        for (const origin of origins) {
            instances.set(parseHost(origin), this.getOptionsForOrigin(origin));
        }
        return instances;
    }
    async syncForm(form) {
        if (isContentScript()) {
            throw new Error('This function only works on extension pages');
        }
        if (typeof form === 'string') {
            form = document.querySelector(form);
        }
        await this.getOptionsForOrigin().syncForm(form);
        const optionsByOrigin = await this.getAllOrigins();
        if (optionsByOrigin.size === 1) {
            return Object.freeze({
                domainCount: 1,
                getSelectedDomain: () => 'default',
                onChange() { },
            });
        }
        const dropdown = document.createElement('select');
        dropdown.addEventListener('change', this._domainChangeHandler.bind(this));
        for (const domain of optionsByOrigin.keys()) {
            const option = document.createElement('option');
            option.value = domain;
            option.textContent = domain;
            dropdown.append(option);
        }
        const wrapper = document.createElement('p');
        wrapper.append('Domain selector: ', dropdown);
        wrapper.classList.add('OptionsSyncPerDomain-picker');
        form.prepend(wrapper, document.createElement('hr'));
        return Object.freeze({
            domainCount: optionsByOrigin.size,
            getSelectedDomain: () => dropdown.value,
            onChange(callback) {
                dropdown.addEventListener('change', () => {
                    callback(dropdown.value);
                });
            },
        });
    }
    getStorageNameForOrigin(origin) {
        return this.#defaultOptions.storageName + '-' + parseHost(origin);
    }
    async _domainChangeHandler(event) {
        const dropdown = event.currentTarget;
        for (const [domain, options] of await this.getAllOrigins()) {
            if (dropdown.value === domain) {
                options.syncForm(dropdown.form);
            }
            else {
                options.stopSyncForm();
            }
        }
    }
}
__decorate([
    memoizeDecorator()
], OptionsSyncPerDomain.prototype, "getOptionsForOrigin", null);
__decorate([
    memoizeDecorator()
], OptionsSyncPerDomain.prototype, "getAllOrigins", null);

export { OptionsSync, OptionsSyncPerDomain as default };
