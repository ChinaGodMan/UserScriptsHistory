function setFetch(fetch) {
}

export { setFetch };
