const PUBLIC_VERSION = '5';

export { PUBLIC_VERSION };
