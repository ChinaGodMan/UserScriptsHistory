var lzString = {exports: {}};

export { lzString as __module };
