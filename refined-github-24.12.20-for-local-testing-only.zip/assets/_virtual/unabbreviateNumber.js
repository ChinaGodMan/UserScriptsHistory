var unabbreviateNumber = {};

export { unabbreviateNumber as __exports };
