var escapeGoat = {};

export { escapeGoat as __exports };
