var abbreviateNumber = {};

export { abbreviateNumber as __exports };
